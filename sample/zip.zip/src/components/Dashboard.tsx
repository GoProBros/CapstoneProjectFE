import { Sidebar } from "./Sidebar";
import { Header } from "./Header";
import { UserSection } from "./UserSection";
import { RevenueSection } from "./RevenueSection";
import { BottomSection } from "./BottomSection";
import { Plus } from "lucide-react";

export function Dashboard() {
  return (
    <div className="min-h-screen bg-bg text-text-main flex">
      <Sidebar />
      <main className="ml-64 p-6 flex-1 flex flex-col gap-4">
        <Header />
        <div className="flex flex-col gap-4">
          <UserSection />
          <RevenueSection />
          <BottomSection />
        </div>
      </main>

      {/* FAB for quick actions */}
      <button className="fixed bottom-8 right-8 w-14 h-14 rounded-full bg-accent text-white shadow-2xl flex items-center justify-center hover:scale-105 active:scale-95 transition-all z-50">
        <Plus className="w-6 h-6" />
      </button>
    </div>
  );
}
