export function Header() {
  return (
    <header className="flex justify-between items-center mb-6">
      <div>
        <h2 className="text-[32px] font-semibold text-text-main tracking-tight">
          Hệ thống Dashboard
        </h2>
        <p className="text-sm text-text-sub">
          Tổng quan hoạt động kinh doanh và dữ liệu người dùng
        </p>
      </div>
      <div className="flex bg-card border border-border rounded-xl p-1">
        <button className="px-4 py-1.5 text-sm font-semibold rounded-lg bg-accent text-white shadow-sm">
          Ngày
        </button>
        <button className="px-4 py-1.5 text-sm font-medium text-text-sub hover:text-text-main">
          Tuần
        </button>
        <button className="px-4 py-1.5 text-sm font-medium text-text-sub hover:text-text-main">
          Tháng
        </button>
        <button className="px-4 py-1.5 text-sm font-medium text-text-sub hover:text-text-main">
          Khoảng
        </button>
      </div>
    </header>
  );
}
