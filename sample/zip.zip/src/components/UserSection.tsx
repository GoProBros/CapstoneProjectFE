import { MoreHorizontal } from "lucide-react";
import {
  LineChart,
  Line,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts";

const newUserChartData = [
  { name: "T1", users: 1000 },
  { name: "T2", users: 1500 },
  { name: "T3", users: 1200 },
  { name: "T4", users: 2000 },
  { name: "T5", users: 2500 },
  { name: "T6", users: 2200 },
  { name: "T7", users: 3000 },
  { name: "T8", users: 2800 },
  { name: "T9", users: 3500 },
  { name: "T10", users: 4000 },
  { name: "T11", users: 3800 },
  { name: "T12", users: 4500 },
];

const userRatioData = [
  { name: "Basic", value: 40, fill: "#0d1c32" },
  { name: "Pro", value: 30, fill: "#006c4a" },
  { name: "Free", value: 30, fill: "#e6e8ea" },
];

export function UserSection() {
  return (
    <section>
      <div className="flex items-center gap-2 mb-6">
        <span className="w-1 h-6 bg-accent rounded-full"></span>
        <h3 className="text-lg font-bold tracking-tight">Thống kê người dùng</h3>
      </div>
      <div className="grid grid-cols-12 gap-4">
        {/* User Cards */}
        <div className="col-span-12 lg:col-span-4 grid grid-cols-1 gap-4">
          <div className="bg-card border border-border p-6 rounded-[24px] transition-all">
            <p className="text-[12px] uppercase tracking-[1px] text-text-sub mb-2">
              Tổng user
            </p>
            <div className="flex items-end justify-between">
              <span className="text-[40px] font-bold tracking-tight display-font leading-none">
                1.254.300
              </span>
              <span className="text-accent flex items-center text-xs font-bold bg-accent-soft px-2 py-1 rounded-full">
                +12%
              </span>
            </div>
          </div>
          <div className="bg-card border border-border p-6 rounded-[24px]">
            <p className="text-[12px] uppercase tracking-[1px] text-text-sub mb-2">
              Paid user
            </p>
            <div className="flex items-end justify-between">
              <span className="text-[40px] font-bold tracking-tight display-font leading-none">
                82.100
              </span>
              <span className="text-text-sub text-xs font-semibold">
                6.5% tổng user
              </span>
            </div>
          </div>
          <div className="bg-card border border-border p-6 rounded-[24px]">
            <p className="text-[12px] uppercase tracking-[1px] text-text-sub mb-2">
              New user/month
            </p>
            <div className="flex items-end justify-between">
              <span className="text-[40px] font-bold tracking-tight display-font leading-none">
                12.450
              </span>
              <span className="text-accent flex items-center text-xs font-bold bg-accent-soft px-2 py-1 rounded-full">
                +8.4%
              </span>
            </div>
          </div>
        </div>

        {/* New User Chart */}
        <div className="col-span-12 lg:col-span-5 bg-card border border-border p-6 rounded-[24px] flex flex-col">
          <div className="flex justify-between items-start mb-4">
            <h4 className="text-[12px] font-bold uppercase tracking-[1px] text-text-sub">
              Biểu đồ người dùng mới theo tháng
            </h4>
            <MoreHorizontal className="text-text-sub cursor-pointer w-5 h-5" />
          </div>
          <div className="flex-1 min-h-[150px] w-full relative">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={newUserChartData}>
                <Line
                  type="monotone"
                  dataKey="users"
                  stroke="var(--color-accent)"
                  strokeWidth={3}
                  dot={false}
                />
              </LineChart>
            </ResponsiveContainer>
            <div className="flex justify-between w-full mt-2 pt-2 border-t border-border text-[10px] text-text-sub font-medium">
              {newUserChartData.map((d) => (
                <span key={d.name}>{d.name}</span>
              ))}
            </div>
          </div>
        </div>

        {/* User Pie Chart */}
        <div className="col-span-12 lg:col-span-3 bg-card border border-border p-6 rounded-[24px] flex flex-col items-center justify-center">
          <h4 className="text-[12px] font-bold uppercase tracking-[1px] text-text-sub mb-6 w-full">
            Tỉ lệ người dùng
          </h4>
          <div className="relative w-32 h-32 mb-6">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={userRatioData}
                  innerRadius={40}
                  outerRadius={50}
                  paddingAngle={0}
                  dataKey="value"
                  stroke="none"
                >
                  {userRatioData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.fill} />
                  ))}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="grid grid-cols-2 gap-4 w-full text-xs">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-text-main"></span>
              <span>Basic</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-accent"></span>
              <span>Pro</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-border"></span>
              <span>Free</span>
            </div>
          </div>
        </div>

        {/* Retention Rate Table */}
        <div className="col-span-12 bg-card border border-border p-6 rounded-[24px]">
          <h4 className="text-[12px] font-bold uppercase tracking-[1px] text-text-sub mb-6">
            Mức độ giữ chân user
          </h4>
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="text-text-sub text-xs uppercase tracking-tight font-bold border-b border-border">
                  <th className="pb-3 px-2">Thời gian</th>
                  <th className="pb-3 px-2">Số lượng User</th>
                  <th className="pb-3 px-2">Tháng 1</th>
                  <th className="pb-3 px-2">Tháng 2</th>
                  <th className="pb-3 px-2">Tháng 3</th>
                  <th className="pb-3 px-2">Tháng 4</th>
                  <th className="pb-3 px-2">Tháng 5</th>
                  <th className="pb-3 px-2">Tháng 6</th>
                </tr>
              </thead>
              <tbody className="text-sm">
                <tr className="border-b border-border hover:bg-bg transition-colors">
                  <td className="py-4 px-2 font-semibold">T1 / 2024</td>
                  <td className="py-4 px-2">12.500</td>
                  <td className="py-4 px-2">
                    <span className="bg-accent-soft text-accent px-2 py-1 rounded-md text-xs font-bold">
                      100%
                    </span>
                  </td>
                  <td className="py-4 px-2">
                    <span className="bg-accent-soft text-accent px-2 py-1 rounded-md text-xs font-bold opacity-80">
                      85%
                    </span>
                  </td>
                  <td className="py-4 px-2">
                    <span className="bg-accent-soft text-accent px-2 py-1 rounded-md text-xs font-bold opacity-70">
                      72%
                    </span>
                  </td>
                  <td className="py-4 px-2">
                    <span className="bg-accent-soft text-accent px-2 py-1 rounded-md text-xs font-bold opacity-60">
                      60%
                    </span>
                  </td>
                  <td className="py-4 px-2">
                    <span className="bg-accent-soft text-accent px-2 py-1 rounded-md text-xs font-bold opacity-50">
                      58%
                    </span>
                  </td>
                  <td className="py-4 px-2">
                    <span className="bg-accent-soft text-accent px-2 py-1 rounded-md text-xs font-bold opacity-40">
                      55%
                    </span>
                  </td>
                </tr>
                <tr className="border-b border-border hover:bg-bg transition-colors">
                  <td className="py-4 px-2 font-semibold">T2 / 2024</td>
                  <td className="py-4 px-2">15.200</td>
                  <td className="py-4 px-2">
                    <span className="bg-accent-soft text-accent px-2 py-1 rounded-md text-xs font-bold">
                      100%
                    </span>
                  </td>
                  <td className="py-4 px-2">
                    <span className="bg-accent-soft text-accent px-2 py-1 rounded-md text-xs font-bold opacity-80">
                      82%
                    </span>
                  </td>
                  <td className="py-4 px-2">
                    <span className="bg-accent-soft text-accent px-2 py-1 rounded-md text-xs font-bold opacity-70">
                      68%
                    </span>
                  </td>
                  <td className="py-4 px-2">
                    <span className="bg-accent-soft text-accent px-2 py-1 rounded-md text-xs font-bold opacity-60">
                      54%
                    </span>
                  </td>
                  <td className="py-4 px-2">
                    <span className="bg-accent-soft text-accent px-2 py-1 rounded-md text-xs font-bold opacity-50">
                      50%
                    </span>
                  </td>
                  <td className="py-4 px-2">-</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </section>
  );
}
