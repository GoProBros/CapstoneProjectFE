import {
  BarChart,
  Bar,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Rectangle,
} from "recharts";

const revenueChartData = [
  { name: "T1", revenue: 400 },
  { name: "T2", revenue: 300 },
  { name: "T3", revenue: 500 },
  { name: "T4", revenue: 450 },
  { name: "T5", revenue: 600 },
  { name: "T6", revenue: 550 },
  { name: "T7", revenue: 700 },
  { name: "T8", revenue: 650 },
  { name: "T9", revenue: 800 },
  { name: "T10", revenue: 750 },
  { name: "T11", revenue: 900 },
  { name: "T12", revenue: 850 },
];

const revenueRatioData = [
  { name: "Pro Monthly", value: 55, fill: "var(--color-text-main)" },
  { name: "Elite Annual", value: 30, fill: "var(--color-accent)" },
  { name: "Others", value: 15, fill: "var(--color-border)" },
];

export function RevenueSection() {
  return (
    <section>
      <div className="flex items-center gap-2 mb-6">
        <span className="w-1 h-6 bg-accent rounded-full"></span>
        <h3 className="text-lg font-bold tracking-tight">Thống kê doanh thu</h3>
      </div>
      <div className="grid grid-cols-12 gap-4">
        {/* Revenue Cards */}
        <div className="col-span-12 lg:col-span-4 grid grid-cols-1 gap-4">
          <div className="bg-card border border-border p-6 rounded-[24px] transition-all">
            <p className="text-[12px] uppercase tracking-[1px] text-text-sub mb-2">
              Tổng doanh thu
            </p>
            <div className="flex items-end justify-between">
              <span className="text-[40px] font-bold tracking-tight display-font leading-none">
                2.450M đ
              </span>
              <span className="text-accent flex items-center text-xs font-bold bg-accent-soft px-2 py-1 rounded-full">
                +15%
              </span>
            </div>
          </div>
          <div className="bg-card border border-border p-6 rounded-[24px]">
            <p className="text-[12px] uppercase tracking-[1px] text-text-sub mb-2">
              Gói top doanh thu
            </p>
            <div className="flex items-end justify-between">
              <span className="text-xl font-bold tracking-tight">
                Platinum Pro Monthly
              </span>
              <span className="text-text-sub text-xs font-semibold">
                42% thị phần
              </span>
            </div>
          </div>
          <div className="bg-card border border-border p-6 rounded-[24px]">
            <p className="text-[12px] uppercase tracking-[1px] text-text-sub mb-2">
              Doanh thu / user (ARPU)
            </p>
            <div className="flex items-end justify-between">
              <span className="text-2xl font-bold tracking-tight display-font">
                29.800 đ
              </span>
              <span className="text-accent flex items-center text-xs font-bold bg-accent-soft px-2 py-1 rounded-full">
                +2.1%
              </span>
            </div>
          </div>
        </div>

        {/* Performance Table */}
        <div className="col-span-12 lg:col-span-8 bg-card border border-border p-6 rounded-[24px]">
          <h4 className="text-[12px] font-bold uppercase tracking-[1px] text-text-sub mb-6">
            Hiệu suất gói đăng ký
          </h4>
          <table className="w-full text-left">
            <thead>
              <tr className="text-text-sub text-xs uppercase font-bold border-b border-border">
                <th className="pb-3 px-2">Tên gói</th>
                <th className="pb-3 px-2">Lượt đăng ký</th>
                <th className="pb-3 px-2 text-right">Doanh thu</th>
                <th className="pb-3 px-2 text-right">Tăng trưởng</th>
              </tr>
            </thead>
            <tbody className="text-sm">
              <tr className="border-b border-border">
                <td className="py-4 px-2 font-semibold">Standard Basic</td>
                <td className="py-4 px-2">42,500</td>
                <td className="py-4 px-2 text-right font-medium">
                  850,000,000
                </td>
                <td className="py-4 px-2 text-right text-accent font-bold">
                  +12%
                </td>
              </tr>
              <tr className="border-b border-border">
                <td className="py-4 px-2 font-semibold">Premium Pro Monthly</td>
                <td className="py-4 px-2">12,200</td>
                <td className="py-4 px-2 text-right font-medium">
                  1,220,000,000
                </td>
                <td className="py-4 px-2 text-right text-accent font-bold">
                  +24%
                </td>
              </tr>
              <tr>
                <td className="py-4 px-2 font-semibold">Enterprise Elite</td>
                <td className="py-4 px-2">350</td>
                <td className="py-4 px-2 text-right font-medium">
                  380,000,000
                </td>
                <td className="py-4 px-2 text-right text-text-sub font-bold">
                  +0.5%
                </td>
              </tr>
            </tbody>
          </table>
        </div>

        {/* Revenue Chart */}
        <div className="col-span-12 lg:col-span-8 bg-card border border-border p-6 rounded-[24px]">
          <h4 className="text-[12px] font-bold uppercase tracking-[1px] text-text-sub mb-6">
            Biểu đồ doanh thu
          </h4>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={revenueChartData}>
                <Bar
                  dataKey="revenue"
                  fill="var(--color-border)"
                  radius={[4, 4, 0, 0]}
                  activeBar={<Rectangle fill="var(--color-accent)" />}
                >
                  {revenueChartData.map((entry, index) => (
                    <Cell
                      key={`cell-${index}`}
                      fill={index === 6 ? "var(--color-accent)" : "var(--color-border)"}
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Revenue Pie */}
        <div className="col-span-12 lg:col-span-4 bg-card border border-border p-6 rounded-[24px]">
          <h4 className="text-[12px] font-bold uppercase tracking-[1px] text-text-sub mb-6">
            Doanh thu theo gói
          </h4>
          <div className="h-64 flex flex-col items-center justify-center">
            <div className="relative w-40 h-40 mb-6">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={revenueRatioData}
                    innerRadius={50}
                    outerRadius={70}
                    paddingAngle={0}
                    dataKey="value"
                    stroke="none"
                  >
                    {revenueRatioData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.fill} />
                    ))}
                  </Pie>
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="space-y-2 w-full text-xs font-semibold">
              <div className="flex justify-between items-center">
                <span className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-text-main"></span>
                  Pro Monthly
                </span>
                <span>55%</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-accent"></span>
                  Elite Annual
                </span>
                <span>30%</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-border"></span>
                  Others
                </span>
                <span>15%</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}


