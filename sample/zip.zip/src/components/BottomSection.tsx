import {
  Shapes,
  List,
  Link as LinkIcon,
  Activity,
  CheckCircle2,
  AlertCircle,
  Info,
} from "lucide-react";

export function BottomSection() {
  return (
    <section className="grid grid-cols-12 gap-4">
      {/* Stock Tickers Control */}
      <div className="col-span-12 lg:col-span-5 bg-card border border-border p-6 rounded-[24px]">
        <div className="flex items-center justify-between mb-6">
          <h4 className="text-[12px] font-bold uppercase tracking-[1px] text-text-sub">
            Mã chứng khoán
          </h4>
          <div className="text-right">
            <span className="text-2xl font-black block">1,842</span>
            <span className="text-[10px] text-text-sub font-medium">
              Tổng số mã niêm yết
            </span>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <button className="bg-bg text-text-main py-2.5 px-4 rounded-lg text-xs font-bold hover:bg-border transition-all flex items-center justify-center gap-2">
            <Shapes className="w-4 h-4" /> Lấy d.sách ngành
          </button>
          <button className="bg-bg text-text-main py-2.5 px-4 rounded-lg text-xs font-bold hover:bg-border transition-all flex items-center justify-center gap-2">
            <List className="w-4 h-4" /> Lấy d.sách mã CK
          </button>
          <button className="bg-bg text-text-main py-2.5 px-4 rounded-lg text-xs font-bold hover:bg-border transition-all flex items-center justify-center gap-2">
            <LinkIcon className="w-4 h-4" /> Nối mã CK với ngành
          </button>
          <button className="bg-bg text-text-main py-2.5 px-4 rounded-lg text-xs font-bold hover:bg-border transition-all flex items-center justify-center gap-2">
            <Activity className="w-4 h-4" /> Lấy chỉ số index
          </button>
        </div>
      </div>

      {/* Top 5 Tickers */}
      <div className="col-span-12 lg:col-span-3 bg-card border border-border p-6 rounded-[24px]">
        <h4 className="text-[12px] font-bold uppercase tracking-[1px] text-text-sub mb-4">
          Top 5 mã CK được q.tâm
        </h4>
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold w-12">VCB</span>
            <div className="w-16 h-4">
              <svg className="w-full h-full" viewBox="0 0 100 20">
                <path
                  d="M0 15 L20 12 L40 18 L60 5 L80 10 L100 2"
                  fill="none"
                  stroke="var(--color-accent)"
                  strokeWidth="2"
                ></path>
              </svg>
            </div>
            <span className="text-xs font-bold text-accent">92.400</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold w-12">FPT</span>
            <div className="w-16 h-4">
              <svg className="w-full h-full" viewBox="0 0 100 20">
                <path
                  d="M0 10 L20 15 L40 5 L60 8 L80 2 L100 4"
                  fill="none"
                  stroke="var(--color-accent)"
                  strokeWidth="2"
                ></path>
              </svg>
            </div>
            <span className="text-xs font-bold text-accent">115.500</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold w-12">VIC</span>
            <div className="w-16 h-4">
              <svg className="w-full h-full" viewBox="0 0 100 20">
                <path
                  d="M0 5 L20 10 L40 8 L60 15 L80 12 L100 18"
                  fill="none"
                  stroke="var(--color-error)"
                  strokeWidth="2"
                ></path>
              </svg>
            </div>
            <span className="text-xs font-bold text-error">42.100</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold w-12">HPG</span>
            <div className="w-16 h-4">
              <svg className="w-full h-full" viewBox="0 0 100 20">
                <path
                  d="M0 15 L20 10 L40 12 L60 5 L80 8 L100 2"
                  fill="none"
                  stroke="var(--color-accent)"
                  strokeWidth="2"
                ></path>
              </svg>
            </div>
            <span className="text-xs font-bold text-accent">28.300</span>
          </div>
        </div>
      </div>

      {/* Log Table */}
      <div className="col-span-12 lg:col-span-4 bg-card border border-border p-6 rounded-[24px]">
        <div className="flex justify-between items-center mb-4">
          <h4 className="text-[12px] font-bold uppercase tracking-[1px] text-text-sub">
            Log
          </h4>
          <button className="text-[10px] font-bold text-accent hover:underline uppercase">
            Xem toàn bộ
          </button>
        </div>
        <div className="space-y-3">
          <div className="flex items-start gap-3 p-2 rounded-lg hover:bg-bg transition-all">
            <CheckCircle2 className="text-accent w-4 h-4 mt-0.5" />
            <div className="flex-1">
              <p className="text-[11px] font-medium leading-tight">
                Cập nhật dữ liệu giá EOD thành công cho 1,540 mã
              </p>
              <span className="text-[10px] text-text-sub">
                10:45 AM - 24/05/2024
              </span>
            </div>
          </div>
          <div className="flex items-start gap-3 p-2 rounded-lg hover:bg-bg transition-all">
            <AlertCircle className="text-error w-4 h-4 mt-0.5" />
            <div className="flex-1">
              <p className="text-[11px] font-medium leading-tight">
                Lỗi kết nối API lấy tin tức từ CafeF
              </p>
              <span className="text-[10px] text-text-sub">
                09:12 AM - 24/05/2024
              </span>
            </div>
          </div>
          <div className="flex items-start gap-3 p-2 rounded-lg hover:bg-bg transition-all">
            <Info className="text-text-sub w-4 h-4 mt-0.5" />
            <div className="flex-1">
              <p className="text-[11px] font-medium leading-tight">
                User #12450 vừa nâng cấp lên gói Pro Monthly
              </p>
              <span className="text-[10px] text-text-sub">
                08:05 AM - 24/05/2024
              </span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
