import {
  LayoutDashboard,
  Users,
  CircleDollarSign,
  Landmark,
  LineChart,
  Newspaper,
  Database,
  HelpCircle,
  LogOut,
} from "lucide-react";

export function Sidebar() {
  return (
    <aside className="flex flex-col fixed left-0 top-0 h-full w-64 z-40 bg-card border-r border-border">
      <div className="p-6">
        <div className="flex items-center gap-3 mb-8">
          <div className="w-10 h-10 bg-accent rounded-lg flex items-center justify-center text-white font-bold">
            KF
          </div>
          <div>
            <h1 className="text-lg font-bold text-text-main tracking-tight">
              KF Stock
            </h1>
            <p className="text-xs text-text-sub font-medium">
              Admin Terminal
            </p>
          </div>
        </div>
        <nav className="space-y-1">
          <a
            className="flex items-center gap-3 border-l-4 border-accent font-bold text-accent bg-accent-soft px-4 py-3 rounded-r-lg"
            href="#"
          >
            <LayoutDashboard className="w-5 h-5" />
            <span className="text-sm">Dashboard</span>
          </a>
          <a
            className="flex items-center gap-3 text-text-sub font-medium px-4 py-3 hover:bg-bg hover:text-text-main rounded-r-lg transition-all"
            href="#"
          >
            <Users className="w-5 h-5" />
            <span className="text-sm">Quản lý người dùng</span>
          </a>
          <a
            className="flex items-center gap-3 text-text-sub font-medium px-4 py-3 hover:bg-bg hover:text-text-main rounded-r-lg transition-all"
            href="#"
          >
            <CircleDollarSign className="w-5 h-5" />
            <span className="text-sm">Quản lý doanh thu</span>
          </a>
          <a
            className="flex items-center gap-3 text-text-sub font-medium px-4 py-3 hover:bg-bg hover:text-text-main rounded-r-lg transition-all"
            href="#"
          >
            <Landmark className="w-5 h-5" />
            <span className="text-sm">Báo cáo tài chính</span>
          </a>
          <a
            className="flex items-center gap-3 text-text-sub font-medium px-4 py-3 hover:bg-bg hover:text-text-main rounded-r-lg transition-all"
            href="#"
          >
            <LineChart className="w-5 h-5" />
            <span className="text-sm">Báo cáo phân tích</span>
          </a>
          <a
            className="flex items-center gap-3 text-text-sub font-medium px-4 py-3 hover:bg-bg hover:text-text-main rounded-r-lg transition-all"
            href="#"
          >
            <Newspaper className="w-5 h-5" />
            <span className="text-sm">Quản lý tin tức</span>
          </a>
          <a
            className="flex items-center gap-3 text-text-sub font-medium px-4 py-3 hover:bg-bg hover:text-text-main rounded-r-lg transition-all"
            href="#"
          >
            <Database className="w-5 h-5" />
            <span className="text-sm">Quản lý dữ liệu</span>
          </a>
        </nav>
      </div>
      <div className="mt-auto p-6 space-y-1">
        <a
          className="flex items-center gap-3 text-text-sub font-medium px-4 py-3 hover:bg-bg hover:text-text-main rounded-r-lg transition-all"
          href="#"
        >
          <HelpCircle className="w-5 h-5" />
          <span className="text-sm">Support</span>
        </a>
        <a
          className="flex items-center gap-3 text-text-sub font-medium px-4 py-3 hover:bg-bg hover:text-text-main rounded-r-lg transition-all"
          href="#"
        >
          <LogOut className="w-5 h-5" />
          <span className="text-sm">Logout</span>
        </a>
      </div>
    </aside>
  );
}
